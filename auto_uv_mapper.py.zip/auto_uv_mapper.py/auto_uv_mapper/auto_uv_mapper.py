bl_info = {
    "name": "Auto UV Mapper",
    "blender": (4, 3, 0),
    "category": "UV",
    "author": "Danesh",
    "description": "Automatically unwraps and packs UVs",
    "version": (1, 0),
    "location": "View3D > UV",
}

import bpy

class AutoUVOperator(bpy.types.Operator):
    """Auto UV Mapper"""
    bl_idname = "uv.auto_uv"
    bl_label = "Auto UV Mapper"
    bl_options = {'REGISTER', 'UNDO'}

    method: bpy.props.EnumProperty(
        name="Unwrap Method",
        items=[
            ("SMART", "Smart UV Project", "Uses Blender's Smart UV Project"),
            ("ANGLE", "Angle Based Unwrap", "Uses angle-based unwrapping")
        ],
        default="SMART"
    )

    def execute(self, context):
        obj = context.active_object

        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object")
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')

        if self.method == "SMART":
            bpy.ops.uv.smart_project(angle_limit=66)
        elif self.method == "ANGLE":
            bpy.ops.uv.unwrap(method='ANGLE_BASED')

        bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, "UV Mapping applied successfully!")
        return {'FINISHED'}

class AutoUVPanel(bpy.types.Panel):
    """Creates a UI Panel in the UV Editor"""
    bl_label = "Auto UV Mapper"
    bl_idname = "UV_PT_auto_mapper"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Auto UV"

    def draw(self, context):
        layout = self.layout
        layout.operator("uv.auto_uv", text="Auto UV Map")

def register():
    bpy.utils.register_class(AutoUVOperator)
    bpy.utils.register_class(AutoUVPanel)

def unregister():
    bpy.utils.unregister_class(AutoUVOperator)
    bpy.utils.unregister_class(AutoUVPanel)

if __name__ == "__main__":
    register()
